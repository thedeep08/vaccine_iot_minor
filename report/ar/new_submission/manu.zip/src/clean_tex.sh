cd src/
rm *.aux *.bbl *.blg *.fls *.fdb* *.toc *.out *.glo *.log
cd ../
